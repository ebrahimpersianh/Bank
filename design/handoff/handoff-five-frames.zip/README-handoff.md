# تحویلِ شش فایل برای پنج فریمِ آماده (9a · 29g · 29h · 29i · 29o)

این‌ها همان پنج موردی‌اند که گفتی فریم دارند و فقط پیاده‌سازی می‌خواهند.

| فریم | فایل | نکته |
|---|---|---|
| `9a` تقویمِ مالی | `FinancialCalendarScreen.kt` + `FinancialCalendarViewModel.kt` | enumِ `DueKind` این فایل با `DueSource`ِ تبِ سررسید **دو چیزِ متفاوت‌اند** - هم‌نام نکن |
| `29g` جزئیاتِ دارایی | `AssetDetailScreen.kt` | خطِ «داده‌ی قیمت از Servix.cc» عمداً از این صفحه برداشته شده و فقط در «قیمتِ روز» مانده |
| `29h` گیتِ مجوزها | `PermissionGateScreen.kt` | مجوزِ معافیتِ باتری هم باید کنارِ پیامک/اعلان بیاید |
| `29i` انتخابِ تاریخ | `CalendarPickerScreen.kt` | چرخِ سه‌ستونه در بخشِ ۶۷ حذف شد؛ همین یکی + `InlineJalaliDateRow` می‌مانند. حالا داخلِ `ModalBottomSheet` باز می‌شود نه به‌جای فرم |
| `29o` یادداشت | `NoteScreen.kt` | افزودنِ عکس به یادداشت هنوز ساخته نشده - اگر در فریم هست بگو |

## قاعده‌های همیشگی (همان هشت‌تای بسته‌ی وام)
- توکن از `ui/theme`؛ هیچ هگزِ هاردکد.
- هر مبلغِ نمایش‌داده‌شده از `LocalPrivacyMode` + `maskIfPrivate` رد شود.
- دیتابیس ریال، نمایش تومان (`rialToToman`/`tomanToRial`, ورودیِ `Long`).
- `AppCard`/`GradientButton`/`AppHeroCard` - کارتِ دستی نساز.
- 🚨 `return` وسطِ کامپوزبل ممنوع (شش مورد تا حالا).
- 🚨 صفحه‌ای که `LazyColumn` دارد هرگز داخلِ `SettingsSubPageScaffold` نرود.
- 🚨 `ModalBottomSheet` و `rememberModalBottomSheetState` نیاز به
  `@OptIn(ExperimentalMaterial3Api::class)` دارند - نبودش بیلدِ ۵۴۵ را شکست.
- `state` را `rememberSaveable` بگیر.

## متنِ نقدی (دوباره فرستاده شد)
`MESSAGE-round7-to-design.md` کنارِ همین فایل است.

## بخشِ ۵۶ و ۵۷ - چیزی لازم نبود
هر دو **از قبل پیاده شده بودند** و نسخه‌ی ما جلوترِ فایلِ بسته است:
- `CoinWalletScreen` ردیفِ «فعال» و کارتِ ترمیم و `LaunchedEffect { refreshRepairable() }` را دارد.
  چهار نگاشت که فایلِ شما لازم داشت: `StreakRepair.days` → **`lostDays`** ·
  `CoinReason.WEEK_COMPLETE` → **`FULL_WEEK`** (و در `data.coin` است نه `core`) ·
  `AppGoldPill` → **`AppGoldPillSoft`** · `ConfirmTone.NEUTRAL` → **`HEAVY_CHANGE`** ·
  و `GradientButton` پارامترِ `text` ندارد، محتوا را به‌صورتِ بلوک می‌گیرد (`enabled` را دارد).
  قیمتِ ترمیم از `GamificationRepository.Reward.STREAK_REPAIR` خوانده می‌شود نه ثابتِ محلی.
- `LoanWidget` هم بازطراحی‌شده است و `jalaliDayIndex`ِ تقریبی با
  `JalaliCalendar.daysBetween`ِ تست‌دارِ `:core` جایگزین شده. `updateAll()` هم وصل است
  (`LoanDataChange` در `:data` خبر می‌دهد، `LoanCalcApplication` صدایش می‌زند).
